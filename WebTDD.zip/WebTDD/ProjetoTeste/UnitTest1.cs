using Microsoft.VisualStudio.TestTools.UnitTesting;
using WebTDD.Negocio;

namespace ProjetoTeste
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Testar_soma_entre_Dois_Numeros()
        {
            var calculadora = new Calculadora();
            Assert.IsTrue(calculadora.Somar(2, 2) == 4);
        }

        [TestMethod]
        public void Testar_Multiplicacao_entre_dois_Numeros()
        {
            var calculadora = new Calculadora();
            Assert.IsTrue(calculadora.Multiplicar(4, 4) == 16);
        }

        [TestMethod]
        public void Testar_Subtrair_entre_dois_Numeros()
        {
            var calculadora = new Calculadora();
            Assert.IsTrue(calculadora.Subtrair(10, 2) == 8);
        }

        [TestMethod]
        public void Testar_Dividir_entre_dois_Numeros()
        {
            var calculadora = new Calculadora();
            Assert.IsTrue(calculadora.Dividir(60, 2) == 30);
        }
    }
}
